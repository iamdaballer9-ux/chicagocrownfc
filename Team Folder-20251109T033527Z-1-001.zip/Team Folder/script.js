// Basic interactivity: mobile nav toggle and schedule date filter + footer year
document.addEventListener('DOMContentLoaded', () => {
  // Year in footer
  document.getElementById('year').textContent = new Date().getFullYear();

  // Mobile nav
  const navToggle = document.getElementById('nav-toggle');
  const mainNav = document.getElementById('main-nav');
  navToggle.addEventListener('click', () => {
    mainNav.classList.toggle('open');
    navToggle.classList.toggle('open');
  });

  // Schedule filter
  const filterDate = document.getElementById('filter-date');
  const clearBtn = document.getElementById('clear-filter');
  const scheduleRows = Array.from(document.querySelectorAll('#schedule-body tr'));

  function applyFilter() {
    const val = filterDate.value; // format YYYY-MM-DD
    if (!val) {
      scheduleRows.forEach(r => r.style.display = '');
      return;
    }
    scheduleRows.forEach(r => {
      const rowDate = r.getAttribute('data-date');
      r.style.display = (rowDate === val) ? '' : 'none';
    });
  }
  filterDate.addEventListener('change', applyFilter);
  clearBtn.addEventListener('click', () => {
    filterDate.value = '';
    applyFilter();
  });

  // Smooth scroll for nav links
  document.querySelectorAll('.main-nav a, .hero-actions a').forEach(a => {
    a.addEventListener('click', (e) => {
      if (a.hash && document.querySelector(a.hash)) {
        e.preventDefault();
        document.querySelector(a.hash).scrollIntoView({ behavior: 'smooth', block: 'start' });
        if (mainNav.classList.contains('open')) mainNav.classList.remove('open');
      }
    });
  });
});
